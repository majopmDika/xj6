const {config} = require('dotenv');
config();
module.exports = {
    // Server configuration
    port: process.env.PORT || 3000, 
    // DAtaBase Confing
    UserDB: process.env.UserDB,
    PassworDB: process.env.passwordDB,
    ServerDB:  process.env.ServerDB,
    DatabaseDB:  process.env.DatabaseDb,
    PortDB:  process.env.PortDB
};
