const mysql = require('mysql2/promise');
const config = require('../config.js');


const dbauth = {
    host: config.ServerDB,
    user: config.UserDB,
    password: config.PassworDB,
    database: config.DatabaseDB,
    port: config.PortDB,
};

console.log(dbauth);

const pool = mysql.createPool(dbauth);

async function getConnection() {
    try {
        return await pool.getConnection();
    } catch (error) {
        console.error('Error obtenido', error)
        throw error;
    }
}
module.exports = getConnection;                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 