const User = require('../models/user.model.js');

async function createUser(data){
    const user = new User(
        data.fullname,
        data.user,
        data.gmail,
        data.password,
        data.status
    );

    let userResult;
    try{
        userResult = await user.createUser();
        return userResult;
    }catch(error){
        if(error.statusCode){
            throw error;
        }else {
            throw {
                ok: false,
                statusCode: 500,
                data: "Ocurrio un error al insertar el usuario"
            }
        }
    }

    return{
        message: 'usuario creado exitosamente'
    };
}


async function viewUser() {
    const user = new User();
    let userResult;
    
    try {
      userResult = await user.viewUser();
    } catch (error) {
      if (error.statusCode) throw error;
      console.log(error);
      throw {
        ok: false,
        statusCode: 500,
        data: 'Ocurrió un error al obtener los usuarios'
      };
    }
  
    return  userResult;
  }


  async function updateUser(options) {
    const user = new User(
      options.fullName, 
      options.user, 
      options.gmail, 
      options.password, 
      options.status, 
    );
  
    try {
      userResult = await user.updateUser(options.user);
    } catch (error) {
      if (error.statusCode) throw error;
      console.log(error);
      throw {
        ok: false,
        statusCode: 500,
        data: 'Ocurrió un error al actualizar el usuario'
      };
    }
  
    return {
      message: 'Usuario actualizado exitosamente',
    };
  }


  async function deleteUser(options) {
    const user = new User();
  
    try {
      userResult = await user.deleteUser(options.user);
    } catch (error) {
      if (error.statusCode) throw error;
      console.log(error);
      throw {
        ok: false,
        statusCode: 500,
        data: 'Ocurrió un error al eliminar el usuario'
      };
    }
  
    return {
      message: 'Usuario eliminado exitosamente',
    };
  }

module.exports = {
    createUser,viewUser,updateUser,deleteUser
};