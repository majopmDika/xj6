const ResponseBody = require('../../../shared/model/ResponseBody.model.js');
const {createUser,viewUser,updateUser,deleteUser} = require("../controller/auth.controller.js")


const 
reateUserAPI= async (req, res) => {
    let { fullname,user,gmail,password,status} = req.body;
    if( !fullname || !user|| !gmail|| !password|| !status) {
        return res.status(400).send (new ResponseBody(400, 'Los campos son requeridos'));
    
    }

    let message;

    try{
        let response =await createUser({fullname,user,gmail,password,status});
        message= new ResponseBody(true,200, response);
    }catch(error){
        if(error.statusCode){
            message= new ResponseBody(false,error.statusCode,error.data);
        }else {
            console.log(error);
            message = new ResponseBody(
                false,
                500,
                "Ocurrio un error al insertar el usuario"
            );
        }
    }
};


const viewUserAPI = async (req, res) => {
    let message;
  
    try {
      let response = await viewUser();
      message = new ResponseBody(true, 200, response);
    } catch (error) {
      if (error.statusCode) {
        message = new ResponseBody(error.ok, error.statusCode, error.data);
      } else {
        console.log(error);
        message = new ResponseBody(false, 500, 'Ocurrió un error al procesar la solicitud.');
      }
    }
  
    return res.json(message);
  };


  const updateUserAPI = async (req, res) => {
    let { fullname,user,gmail,password,status } = req.body;
    let message;
  
    if (!user) {
      return res.json(new ResponseBody(false, 400, 'El ID del usuario es requerido.'));
    }
  
    try {
      let response = await updateUser({ fullname,user,gmail,password,status });
      message = new ResponseBody(true, 200, response);
    } catch (error) {
      if (error.statusCode) {
        message = new ResponseBody(error.ok, error.statusCode, error.data);
      } else {
        console.log(error);
        message = new ResponseBody(false, 500, 'Ocurrió un error al procesar la solicitud.');
      }
    }
  
    return res.json(message);
  }

  
  const deleteUserAPI = async (req, res) => {
    let { user } = req.body;
    let message;
  
    if (!user) {
      return res.json(new ResponseBody(false, 400, 'El ID del usuario es requerido.'));
    }
  
    try {
      let response = await deleteUser({ user });
      message = new ResponseBody(true, 200, response);
    } catch (error) {
      if (error.statusCode) {
        message = new ResponseBody(error.ok, error.statusCode, error.data);
      } else {
        console.log(error);
        message = new ResponseBody(false, 500, 'Ocurrió un error al procesar la solicitud.');
      }
    }
  
    return res.json(message);
  }

module.exports = {
    createUserAPI
};

module.exports = {
    viewUserAPI
};

module.exports = {
    updateUserAPI
};

module.exports = {
    deleteUserAPI
};