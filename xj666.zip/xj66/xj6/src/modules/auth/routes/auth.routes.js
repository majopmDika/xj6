const Router = require('express');

//API middleware
const {createUserAPI, viewUserAPI, updateUserAPI, deleteUserAPI} = require('../api/auth.api.js');

//inicializar router

const router = Router();

//Rutas post

router.post('/auth/createUser', createUserAPI);
router.get('/auth/viewUser', viewUserAPI);
router.put('/auth/updateUser', updateUserAPI);
router.delete('/auth/deleteUser', deleteUserAPI);

module.exports = router;