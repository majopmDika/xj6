const getConnection = require('../../../inteface/DBconn.js');

class Stock {
   constructor(name,num,cantity){
    this.name = name;
    this.num = num;
    this.cantity = cantity;
   }
        
async createStock(){
    const connection = await getConnection();
    try{
        const [result] = await connection.query(
            `INSERT INTO inventario
            (producto,numero_serie,cantidad)
            VALUES (?,?,?)`,
            [this.name,this.num,this.cantity]
        );

        const stockId= result.insertId;

        return {id: stockId};

    }catch(error){
        console.log(error);
        throw{
            ok:false,
            statusCode:500,
            data: 'Ocurrio un error al insertar el producto'
        }
    }finally{
        connection.release();
    }
}


async viewStock() {
    const connection = await getConnection();

    try {
      // Ejecuta la consulta de selección
      const [result] = await connection.query(`
        SELECT 
        producto as name,
        numero_serie as num,
        cantidad as cantity,
        FROM inventario
      `);

      return result; // Devuelve el resultado de la consulta
    } catch (error) {
      console.log(error);
      throw {
        ok: false,
        statusCode: 500,
        data: 'Ocurrió un error al obtener los productos'
      };
    } finally {
      connection.release(); // Libera la conexión de vuelta al pool
    }
  }

async updateStock(stockId) {
    const connection = await getConnection();

    try {
      // Ejecuta la consulta de actualización
      await connection.query(`
        UPDATE inventario
        SET producto = ?,
        numero_serie = ?,
        cantidad = ?,
        WHERE numero_serie = ?
      `, [this.name, this.num, this.cantity, stockId]);

      return { id: stockId}; // Devuelve el ID del usuario actualizado
    } catch (error) {
      console.log(error);
      throw {
        ok: false,
        statusCode: 500,
        data: 'Ocurrió un error al actualizar el producto'
      };
    } finally {
      connection.release(); // Libera la conexión de vuelta al pool
    }
  }

  async deleteStock(stockId) {
    const connection = await getConnection();

    try {
      // Ejecuta la consulta de eliminación
      await connection.query(`
        DELETE FROM inventario
        WHERE numero_serie = ?
      `, [stockId]);

      return { id: stockId }; // Devuelve el ID del usuario eliminado
    } catch (error) {
      console.log(error);
      throw {
        ok: false,
        statusCode: 500,
        data: 'Ocurrió un error al eliminar el producto'
      };
    } finally {
      connection.release(); // Libera la conexión de vuelta al pool
    }
  }
}

module.exports = Stock;