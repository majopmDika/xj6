const Router = require('express');

//API middleware
const { createStockAPI, viewStockAPI, uptadeStockAPI, deleteStockAPI} = require('../api/stock.api.js');

//inicializar router

const router = Router();

//Rutas post

router.post('/stock/createUser', createStockAPI);
// router.get('/stock/viewStock', viewStockAPI);
// router.put('/stock/uptadeStock', uptadeStockAPI);
// router.post('/stock/deleteStock', deleteStockAPI);

module.exports = router;
