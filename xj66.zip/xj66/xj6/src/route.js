const Router = require('express');
const router = Router();

// import routes
const authRoutes= require('./modules/auth/routes/auth.routes.js');
const stockRoutes= require('./modules/stock/routes/stock.routes.js');

//status api enpointment
router.get('/api-status', (req, res)=>{
    return res.send({'status': 'on'});
});

//user routes
router.use(authRoutes);
router.use(stockRoutes);

module.exports = router;