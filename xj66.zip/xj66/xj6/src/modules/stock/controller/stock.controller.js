const Stock = require('../models/Stock.model.js');

async function createStock(data){
    const stock = new Stock(
        data.producto,
        data.numero_serie,
        data.cantidad);

    let stockResult;
    try{
        stockResult = await stock.createStock();
        return stockResult;
    }catch(error){
        if(error.statusCode){
            throw error;
        }else {
            throw {
                ok: false,
                statusCode: 500,
                data: "Ocurrio un error con el invetario"
            }
        }
    }

    return{
        message: 'Ocurrio un error con el invetario'
    };
}

module.exports = {
    createStock,
}