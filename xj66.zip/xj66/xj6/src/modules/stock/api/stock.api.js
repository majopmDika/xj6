const ResponseBody = require('../../../shared/model/ResponseBody.model.js');
const {createStock} = require("../controller/stock.controller.js")

const createStockAPI= async (req, res) => {
    let { producto,numero_serie,cantidad} = req.body;
    if(producto || numero_serie || cantidad){
        return res.status(400).send (new ResponseBody(400, 'Los campos son requeridos'));
    
    }

    let message;

    try{
        let response =await createStock({producto,numero_serie,cantidad});
        message= new ResponseBody(true,200, response);
    }catch(error){
        if(error.statusCode){
            message= new ResponseBody(false,error.statusCode,error.data);
        }else {
            console.log(error);
            message = new ResponseBody(
                false,
                500,
                "Ocurrio un error al insertar el usuario"
            );
        }
    }
};


module.exports = {
    createStockAPI
};